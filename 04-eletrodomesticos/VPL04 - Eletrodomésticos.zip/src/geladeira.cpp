#include "geladeira.hpp"

// Adicione seus metodos / construtores aqui