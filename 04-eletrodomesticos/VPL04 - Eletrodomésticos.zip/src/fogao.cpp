#include "fogao.hpp"

// Adicione seus metodos / construtores aqui

