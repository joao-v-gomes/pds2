#ifndef GELADEIRA_HPP
#define GELADEIRA_HPP

#include <iostream>

class Geladeira {
    private:
    // Adicione suas variaveis globais aqui

    public:
    // Adicione a assinatura dos seus metodos / construtores aqui

};

#endif