#ifndef FOGAO_HPP
#define FOGAO_HPP

#include <iostream>

class Fogao {
    private:
    // Adicione suas variaveis globais aqui

    public:
    // Adicione a assinatura dos seus metodos / construtores aqui
};

#endif